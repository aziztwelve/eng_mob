import React from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { useCourse, useEnrollCourse } from '@/hooks/use-courses';

export default function CourseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t } = useTranslation();
  const { data: course, isLoading, error } = useCourse(id);
  const enrollMutation = useEnrollCourse();

  const handleEnroll = () => {
    if (id) {
      enrollMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <View className="flex-1 bg-transparent items-center justify-center">
        <ActivityIndicator size="large" color="#2FA8E6" />
        <Text className="text-mieo-body mt-4">{t('courses.loading_one')}</Text>
      </View>
    );
  }

  if (error || !course) {
    return (
      <View className="flex-1 bg-transparent items-center justify-center px-6">
        <Text className="text-4xl mb-4">😕</Text>
        <Text className="text-mieo-heading font-nunito-bold text-lg mb-2">
          {t('courses.not_found')}
        </Text>
        <Text className="text-mieo-body text-center">
          {(error as any)?.message || t('courses.not_found_desc')}
        </Text>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-transparent">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Course Header */}
        <View className="bg-mieo-surface p-6 border-b-4 border-mieo-stroke">
          {/* Course Image Placeholder */}
          <View className="bg-mieo-bg rounded-3xl h-48 mb-4 items-center justify-center">
            <Text className="text-6xl">📚</Text>
          </View>

          <Text className="text-3xl font-nunito-black text-mieo-heading mb-2">
            {course.title}
          </Text>

          <Text className="text-mieo-body text-base mb-4">
            {course.description}
          </Text>

          {/* Course Meta */}
          <View className="flex-row items-center space-x-3 mb-4">
            <View className="bg-mieo-primary/20 px-4 py-2 rounded-full">
              <Text className="text-mieo-primary-full font-nunito-bold uppercase">
                {course.level}
              </Text>
            </View>
            
            {course.rating && (
              <View className="flex-row items-center bg-mieo-bg px-3 py-2 rounded-full">
                <Text className="text-yellow-500 mr-1">⭐</Text>
                <Text className="text-mieo-heading font-semibold">
                  {course.rating.toFixed(1)}
                </Text>
              </View>
            )}

            {course.students && (
              <View className="bg-mieo-bg px-3 py-2 rounded-full">
                <Text className="text-mieo-heading font-semibold">
                  {course.students.toLocaleString()} 👥
                </Text>
              </View>
            )}
          </View>

          {course.instructor && (
            <View className="flex-row items-center">
              <View className="bg-mieo-primary rounded-full w-10 h-10 items-center justify-center mr-3">
                <Text className="text-xl">👨‍🏫</Text>
              </View>
              <View>
                <Text className="text-mieo-body text-xs">{t('courses.instructor')}</Text>
                <Text className="text-mieo-heading font-nunito-bold">{course.instructor}</Text>
              </View>
            </View>
          )}
        </View>

        {/* What You'll Learn */}
        {course.whatYouWillLearn && course.whatYouWillLearn.length > 0 && (
          <View className="p-6 border-b-2 border-mieo-stroke">
            <Text className="text-xl font-nunito-black text-mieo-heading mb-4">
              {t('courses.what_learn')}
            </Text>
            {course.whatYouWillLearn.map((item, index) => (
              <View key={index} className="flex-row mb-3">
                <Text className="text-mieo-primary-full mr-2">✓</Text>
                <Text className="text-mieo-heading flex-1">{item}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Course Modules */}
        {course.modules && course.modules.length > 0 && (
          <View className="p-6">
            <Text className="text-xl font-nunito-black text-mieo-heading mb-4">
              {t('courses.content')}
            </Text>
            {course.modules.map((module, moduleIndex) => (
              <View key={moduleIndex} className="bg-mieo-surface rounded-2xl p-4 mb-3 border-2 border-mieo-stroke">
                <Text className="text-mieo-heading font-nunito-bold text-lg mb-2">
                  {module.title}
                </Text>
                {module.lessons.map((lesson, lessonIndex) => (
                  <View key={lessonIndex} className="flex-row items-center py-2">
                    <View className="w-6 h-6 rounded-full bg-mieo-bg items-center justify-center mr-3">
                      <Text className="text-xs font-nunito-bold text-mieo-body">
                        {lessonIndex + 1}
                      </Text>
                    </View>
                    <Text className="text-mieo-body flex-1">
                      {lesson.title}
                    </Text>
                    {lesson.status === 'completed' && (
                      <Text className="text-mieo-primary-full">✓</Text>
                    )}
                    {lesson.status === 'locked' && (
                      <Text className="text-mieo-body">🔒</Text>
                    )}
                  </View>
                ))}
              </View>
            ))}
          </View>
        )}

        {/* Bottom Padding */}
        <View className="h-24" />
      </ScrollView>

      {/* Enroll Button - Fixed at bottom */}
      <View className="absolute bottom-0 left-0 right-0 bg-mieo-surface border-t-2 border-mieo-stroke p-4">
        <Pressable
          onPress={handleEnroll}
          disabled={enrollMutation.isPending}
          className="bg-mieo-primary rounded-3xl py-4 shadow-lg active:scale-95"
          style={{
            shadowColor: '#FFD84A',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <Text className="text-center text-white font-nunito-black text-lg uppercase tracking-wide">
            {enrollMutation.isPending ? t('courses.enrolling') : t('courses.enroll')}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
