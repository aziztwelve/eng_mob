import { KeyboardLift } from '@/components/keyboard-lift';
import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { useCourses } from '@/hooks/use-courses';
import { Course } from '@/types/api';

const LEVEL_FILTERS = [
  { value: null },
  { value: 'A1-A2' },
  { value: 'B1' },
  { value: 'B2' },
  { value: 'C1-C2' },
];

export default function CoursesScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const { data: courses, isLoading, error } = useCourses({
    search: search || undefined,
    level: selectedLevel ? [selectedLevel] : undefined,
  });

  const renderCourseCard = ({ item }: { item: Course }) => (
    <Pressable
      onPress={() => router.push(`/(tabs)/courses/${item.id}`)}
      className="bg-mieo-surface rounded-3xl p-4 mb-4 border-[1.5px] border-b-4 border-mieo-stroke active:scale-95"
    >
      {/* Course Image Placeholder */}
      <View className="bg-mieo-bg rounded-2xl h-40 mb-3 items-center justify-center">
        <Text className="text-4xl">📚</Text>
      </View>

      {/* Course Info */}
      <Text className="text-mieo-heading font-nunito-black text-lg mb-1" numberOfLines={2}>
        {item.title}
      </Text>
      
      <Text className="text-mieo-body text-sm mb-3" numberOfLines={2}>
        {item.description}
      </Text>

      {/* Course Meta */}
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center space-x-2">
          <View className="bg-mieo-primary/20 px-3 py-1 rounded-full">
            <Text className="text-mieo-primary-full font-nunito-bold text-xs uppercase">
              {item.level}
            </Text>
          </View>
          {item.rating && (
            <View className="flex-row items-center">
              <Text className="text-yellow-500 mr-1">⭐</Text>
              <Text className="text-mieo-heading font-semibold text-sm">
                {item.rating.toFixed(1)}
              </Text>
            </View>
          )}
        </View>
        
        {item.students && (
          <Text className="text-mieo-body text-xs">
            {t('courses.students', { count: item.students.toLocaleString() })}
          </Text>
        )}
      </View>
    </Pressable>
  );

  return (
    <View className="flex-1 bg-transparent">
<KeyboardLift>
      {/* Header */}
      <View className="bg-mieo-surface border-b-2 border-mieo-stroke px-4 pt-12 pb-4">
        <Text className="text-3xl font-nunito-black text-mieo-primary-full mb-4">
          {t('courses.title')}
        </Text>

        {/* Search Bar */}
        <TextInput
          className="bg-transparent border-2 border-mieo-stroke rounded-2xl px-4 py-3 text-mieo-heading mb-3"
          placeholder={t('courses.search_ph')}
          placeholderTextColor="#666"
          value={search}
          onChangeText={setSearch}
        />

        {/* Level Filters */}
        <View className="flex-row space-x-2">
          {LEVEL_FILTERS.map((filter) => (
            <Pressable
              key={filter.value ?? 'all'}
              onPress={() => setSelectedLevel(filter.value)}
              className={`px-4 py-2 rounded-full border-2 ${
                selectedLevel === filter.value
                  ? 'bg-mieo-primary border-mieo-primary'
                  : 'bg-transparent border-mieo-stroke'
              }`}
            >
              <Text
                className={`font-nunito-bold text-sm ${
                  selectedLevel === filter.value
                    ? 'text-white'
                    : 'text-mieo-body'
                }`}
              >
                {filter.value ?? t('courses.filter_all')}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Course List */}
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color="#2FA8E6" />
          <Text className="text-mieo-body mt-4">{t('courses.loading')}</Text>
        </View>
      ) : error ? (
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-4xl mb-4">😕</Text>
          <Text className="text-mieo-heading font-nunito-bold text-lg mb-2">
            {t('courses.error_title')}
          </Text>
          <Text className="text-mieo-body text-center">
            {(error as any)?.message || t('courses.error_default')}
          </Text>
        </View>
      ) : !courses || courses.length === 0 ? (
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-4xl mb-4">🔍</Text>
          <Text className="text-mieo-heading font-nunito-bold text-lg mb-2">
            {t('courses.empty_title')}
          </Text>
          <Text className="text-mieo-body text-center">
            {t('courses.empty_desc')}
          </Text>
        </View>
      ) : (
        <FlatList
          data={courses}
          renderItem={renderCourseCard}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16 }}
          showsVerticalScrollIndicator={false}
        />
      )}
</KeyboardLift>
    </View>
  );
}
