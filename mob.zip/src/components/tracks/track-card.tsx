import React from 'react';
import { View, Text, Pressable, Image } from 'react-native';
import { useRouter } from 'expo-router';
import type { Track, TrackType } from '@/types/api';
import { neon, neonStyles } from '@/components/neon-screen';

const TYPE_META: Record<TrackType, { label: string; emoji: string; tone: string }> = {
  daily:    { label: 'Daily',    emoji: '🗓️', tone: 'bg-blue-500/20 border-blue-500/40' },
  stories:  { label: 'Stories',  emoji: '📖', tone: 'bg-purple-500/20 border-purple-500/40' },
  podcast:  { label: 'Podcast',  emoji: '🎧', tone: 'bg-orange-500/20 border-orange-500/40' },
  thematic: { label: 'Topic',    emoji: '✨', tone: 'bg-emerald-500/20 border-emerald-500/40' },
};

function typeMeta(type: string) {
  return TYPE_META[(type as TrackType)] ?? TYPE_META.thematic;
}

export function TrackCard({ track }: { track: Track }) {
  const router = useRouter();
  const meta = typeMeta(track.track_type);

  return (
    <Pressable
      onPress={() => router.push(`/(tabs)/tracks/${track.code || track.id}`)}
      style={{ backgroundColor: 'rgba(20,26,36,0.72)', borderRadius: 28, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.09)', overflow: 'hidden' }}
    >
      {/* Header image / fallback */}
      {track.icon_url ? (
        <Image
          source={{ uri: track.icon_url }}
          style={{ width: '100%', height: 128, backgroundColor: '#1c2433' }}
          resizeMode="cover"
        />
      ) : (
        <View style={{ width: '100%', height: 128, backgroundColor: 'rgba(255,255,255,0.03)', alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 56 }}>{meta.emoji}</Text>
        </View>
      )}

      <View style={{ padding: 16 }}>
        {/* Tag row */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', backgroundColor: 'rgba(255,255,255,0.04)' }}>
            <Text style={{ marginRight: 4 }}>{meta.emoji}</Text>
            <Text style={{ color: neon.text, fontWeight: '800', fontSize: 12 }}>{meta.label}</Text>
          </View>
          {!!track.language && (
            <View style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: neon.border }}>
              <Text style={{ color: neon.text, fontWeight: '800', fontSize: 12, textTransform: 'uppercase' }}>{track.language}</Text>
            </View>
          )}
          {!!track.level && (
            <View style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, borderWidth: 1, borderColor: neon.border }}>
              <Text style={{ color: neon.text, fontWeight: '800', fontSize: 12 }}>{track.level}</Text>
            </View>
          )}
        </View>

        <Text style={{ color: neon.text, fontWeight: '900', fontSize: 18, marginBottom: 4 }} numberOfLines={2}>
          {track.title}
        </Text>
        {!!track.description && (
          <Text style={{ color: neon.muted, fontSize: 14, lineHeight: 20 }} numberOfLines={2}>
            {track.description}
          </Text>
        )}

        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginTop: 14 }}>
          <Text style={{ color: neon.primary, fontWeight: '800' }}>Открыть →</Text>
        </View>
      </View>
    </Pressable>
  );
}
