import React from 'react';
import { StyleSheet, View, type ViewStyle } from 'react-native';
import Svg, { Defs, LinearGradient as SvgLinearGradient, Stop, Text as SvgText } from 'react-native-svg';

export const neon = {
  bg: '#0A0E1A',
  surface: '#111827',
  surface2: '#1A2232',
  border: '#1E2636',
  primary: '#2EECC8',
  cyan: '#28DCE9',
  purple: '#A855FF',
  xp: '#FFD54F',
  streak: '#FF9344',
  hearts: '#FF4D8D',
  diamond: '#35DCEB',
  greenHero: '#0F5F3A',
  greenHeroBorder: '#18C07A',
  goldLeague: '#3D2E14',
  goldBorder: '#8F6819',
  tipBg: '#1A2560',
  navInactive: '#556070',
  text: '#FFFFFF',
  muted: '#8B98B0',
  ink: '#001A12',
} as const;

export const neonStyles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: neon.bg,
  },
  surface: {
    backgroundColor: neon.surface,
    borderWidth: 1,
    borderColor: neon.border,
  },
  title: {
    color: neon.primary,
    fontSize: 34,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  subtitle: {
    color: neon.muted,
    fontSize: 15,
    fontWeight: '400',
    marginTop: 4,
  },
  primaryText: {
    color: neon.primary,
  },
  cta: {
    borderRadius: 16,
    paddingVertical: 15,
    alignItems: 'center',
    shadowColor: neon.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.55,
    shadowRadius: 24,
    elevation: 8,
  },
});

export function NeonScreen({ children, style }: { children: React.ReactNode; style?: ViewStyle | ViewStyle[] }) {
  return (
    <View style={[neonStyles.screen, ...(Array.isArray(style) ? style : [style])]}>
      {children}
    </View>
  );
}

export function GradientTitle({
  children,
  width = 340,
  fontSize = 34,
}: {
  children: string;
  width?: number;
  fontSize?: number;
}) {
  const height = Math.ceil(fontSize * 1.3);

  return (
    <View
      style={{
        width,
        height,
        shadowColor: neon.primary,
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.35,
        shadowRadius: 14,
      }}
    >
      <Svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        <Defs>
          <SvgLinearGradient id="titleGradient" x1="0" y1="0" x2="1" y2="0">
            <Stop offset="0" stopColor={neon.primary} />
            <Stop offset="0.55" stopColor={neon.cyan} />
            <Stop offset="1" stopColor={neon.cyan} />
          </SvgLinearGradient>
        </Defs>
        <SvgText
          x="0"
          y={fontSize}
          fill="url(#titleGradient)"
          fontSize={fontSize}
          fontWeight="900"
          fontFamily="Nunito_900Black"
        >
          {children}
        </SvgText>
      </Svg>
    </View>
  );
}
