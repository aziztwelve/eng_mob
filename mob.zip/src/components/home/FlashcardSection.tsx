import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { neon, neonStyles } from '@/components/neon-screen';

const S = {
  surface: neonStyles.surface,
} as const;

// Mock flashcard data
const flashcards = [
  { id: 1, front: 'Hello', back: 'Привет', learned: false },
  { id: 2, front: 'Thank you', back: 'Спасибо', learned: true },
  { id: 3, front: 'Good morning', back: 'Доброе утро', learned: false },
];

export function FlashcardSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const current = flashcards[currentIndex];
  const learned = flashcards.filter(c => c.learned).length;
  const total = flashcards.length;

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((currentIndex + 1) % flashcards.length);
  };

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <View style={{ paddingHorizontal: 18, marginTop: 18 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
          <View style={{
            width: 30, height: 30, borderRadius: 9,
            backgroundColor: 'rgba(255,213,79,0.14)', alignItems: 'center', justifyContent: 'center',
          }}>
            <Text>🎴</Text>
          </View>
          <Text style={{ fontSize: 19, fontWeight: '900', color: neon.text }}>
            Флешкарты
          </Text>
        </View>
        <Text style={{ color: neon.muted, fontWeight: '700', fontSize: 13 }}>
          {learned}/{total} изучено
        </Text>
      </View>

      <Pressable onPress={handleFlip} style={[S.surface, { borderRadius: 18, padding: 20, minHeight: 160, justifyContent: 'center', alignItems: 'center' }]}>
        <LinearGradient
          colors={isFlipped ? [neon.primary, neon.cyan] : ['rgba(40,220,233,0.1)', 'rgba(46,236,200,0.1)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 18 }}
        />
        <Text style={{ color: neon.muted, fontSize: 12, fontWeight: '700', marginBottom: 8 }}>
          {isFlipped ? 'Перевод' : 'Слово'}
        </Text>
        <Text style={{ color: neon.text, fontSize: 28, fontWeight: '900', textAlign: 'center' }}>
          {isFlipped ? current.back : current.front}
        </Text>
      </Pressable>

      <View style={{ flexDirection: 'row', gap: 12, marginTop: 12 }}>
        <Pressable
          onPress={handleNext}
          style={[S.surface, { flex: 1, borderRadius: 14, padding: 14, alignItems: 'center' }]}
        >
          <Text style={{ color: neon.text, fontWeight: '800', fontSize: 14 }}>Следующая →</Text>
        </Pressable>
      </View>
    </View>
  );
}
