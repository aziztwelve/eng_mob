import React, { useMemo } from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useLogout, useCurrentUser } from '@/hooks/use-auth';
import { useUserStats } from '@/hooks/use-user-stats';
import { useMyAchievements } from '@/hooks/use-achievements';
import { DailyGoalRing } from '@/components/gamification';
import { tsToDate } from '@/lib/api-client';
import { neon, neonStyles } from '@/components/neon-screen';

const S = {
  surface: neonStyles.surface,
} as const;

const LOCKED_BADGES = [
  { emoji: '🔥', name: 'Серия 7' },
  { emoji: '🎯', name: 'Меткий' },
  { emoji: '🦉', name: 'Сова' },
  { emoji: '💎', name: '1000 XP' },
  { emoji: '📚', name: '10 уроков' },
  { emoji: '🏆', name: 'Лига' },
];

const MENU = [
  { emoji: '📊', bg: 'rgba(40,220,233,0.14)',  label: 'Статистика',   href: '/profile/stats' },
  { emoji: '🔥', bg: 'rgba(255,147,68,0.14)',  label: 'Серия',        href: '/profile/streak' },
  { emoji: '💪', bg: 'rgba(46,236,200,0.14)',   label: 'Сила навыков', href: '/profile/strength' },
  { emoji: '🔔', bg: 'rgba(255,77,141,0.14)',  label: 'Уведомления',  href: '/profile/notifications' },
  { emoji: '⚙️', bg: 'rgba(168,85,255,0.15)', label: 'Настройки',    href: '/profile/settings' },
] as const;

export default function ProfileScreen() {
  const router = useRouter();
  const logout = useLogout();
  const { data: user } = useCurrentUser();
  const { data: stats } = useUserStats();
  const mine = useMyAchievements();

  const unlocked = useMemo(() => {
    return (mine.data?.achievements ?? [])
      .slice()
      .sort((a, b) => {
        const da = tsToDate(a.unlocked_at)?.getTime() ?? 0;
        const db = tsToDate(b.unlocked_at)?.getTime() ?? 0;
        return db - da;
      })
      .slice(0, 4);
  }, [mine.data]);

  const streak = stats?.current_streak ?? 0;
  const xpGoal = 20;
  const xpToday = Math.min(stats?.weekly_xp ?? 0, xpGoal);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: 'transparent' }} contentContainerStyle={{ paddingBottom: 110 }}>
      {/* Profile head */}
      <View style={{ alignItems: 'center', paddingTop: 6, paddingBottom: 4, paddingHorizontal: 18 }}>
        <LinearGradient
          colors={[neon.primary, neon.cyan]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            width: 96, height: 96, borderRadius: 32,
            alignItems: 'center', justifyContent: 'center', marginBottom: 10,
            
          }}
        >
          <Text style={{ fontSize: 44 }}>🦉</Text>
        </LinearGradient>
        <Text style={{ color: neon.text, fontWeight: '900', fontSize: 21 }}>
          {user?.name || user?.username || 'Камол'}
        </Text>
        <Text style={{ color: neon.muted, fontSize: 13, fontWeight: '600', marginTop: 2 }}>
          English · A2 · {streak > 0 ? `в строю ${streak} ${streak === 1 ? 'день' : 'дней'} 🔥` : 'Начни серию!'}
        </Text>
      </View>

      <View style={{ paddingHorizontal: 18, gap: 14 }}>
        {/* Daily goal ring card */}
        <View style={[S.surface, { borderRadius: 20, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 16, marginTop: 10 }]}>
          <DailyGoalRing size={120} />
          <View style={{ flex: 1 }}>
            <Text style={{ color: neon.text, fontWeight: '900', fontSize: 16 }}>
              {xpToday >= xpGoal ? 'Цель дня выполнена! 🎉' : 'Цель дня почти готова!'}
            </Text>
            <Text style={{ color: neon.muted, fontSize: 13, fontWeight: '600', marginTop: 4 }}>
              {xpToday >= xpGoal
                ? 'Отличная работа!'
                : `Ещё ${xpGoal - xpToday} XP до награды`}
            </Text>
            {xpToday < xpGoal && (
              <Pressable
                onPress={() => router.push('/(tabs)/practice')}
                style={{
                  borderRadius: 16, alignItems: 'center', marginTop: 12,
                  overflow: 'hidden',
                }}
              >
                <LinearGradient
                  colors={[neon.primary, neon.cyan]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ width: '100%', alignItems: 'center', paddingVertical: 12 }}
                >
                  <Text style={{ color: neon.ink, fontWeight: '900', fontSize: 17 }}>Добить цель</Text>
                </LinearGradient>
              </Pressable>
            )}
          </View>
        </View>

        {/* Achievements strip */}
        <View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
              <View style={{
                width: 30, height: 30, borderRadius: 9,
                backgroundColor: 'rgba(255,213,79,0.14)', alignItems: 'center', justifyContent: 'center',
              }}>
                <Text>🏆</Text>
              </View>
              <Text style={{ color: '#fff', fontWeight: '900', fontSize: 19 }}>Достижения</Text>
            </View>
            <Pressable onPress={() => router.push('/profile/achievements')}>
              <Text style={[neonStyles.primaryText, { fontWeight: '800', fontSize: 14 }]}>
                Все →
              </Text>
            </Pressable>
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
            {/* Unlocked */}
            {unlocked.map((ua) => (
              <View key={ua.achievement.id} style={[S.surface, { width: 72, height: 84, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 10, gap: 4 }]}>
                <View>
                  <Text style={{ fontSize: 26 }}>🏅</Text>
                </View>
                <Text style={{ color: neon.muted, fontSize: 10, fontWeight: '800', textAlign: 'center' }} numberOfLines={2}>
                  {ua.achievement.title}
                </Text>
              </View>
            ))}
            {/* Locked placeholders */}
            {LOCKED_BADGES.map((b) => (
              <View key={b.name} style={[S.surface, { width: 72, height: 84, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 10, gap: 4, opacity: 0.4 }]}>
                <View>
                  <Text style={{ fontSize: 26 }}>{b.emoji}</Text>
                </View>
                <Text style={{ color: neon.muted, fontSize: 10, fontWeight: '800', textAlign: 'center' }}>
                  {b.name}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Menu items */}
        <View style={{ gap: 10 }}>
          {MENU.map((item) => (
            <Pressable
              key={item.href}
              onPress={() => router.push(item.href as any)}
              style={{
                flexDirection: 'row', alignItems: 'center',
                padding: 15, gap: 14, borderRadius: 16,
                backgroundColor: neon.surface,
                borderWidth: 1,
                borderColor: neon.border,
              }}
            >
              <View style={{
                width: 44, height: 44, borderRadius: 16,
                backgroundColor: item.bg,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Text style={{ fontSize: 18 }}>{item.emoji}</Text>
              </View>
              <Text style={{ flex: 1, color: neon.text, fontWeight: '800', fontSize: 15 }}>{item.label}</Text>
              <Text style={{ color: neon.muted, fontSize: 20 }}>›</Text>
            </Pressable>
          ))}
        </View>

        {/* Logout */}
        <Pressable
          onPress={() => logout.mutate()}
          disabled={logout.isPending}
          style={[S.surface, {
            borderRadius: 16, paddingVertical: 14, alignItems: 'center',
            borderColor: 'rgba(255,77,141,0.30)', marginTop: 4,
          }]}
        >
          <Text style={{ color: '#FF4D8D', fontWeight: '900', fontSize: 15 }}>
            {logout.isPending ? 'Выходим...' : 'Выйти из аккаунта'}
          </Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}
