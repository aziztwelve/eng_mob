import React from 'react';
import { Tabs } from 'expo-router';
import { View, Dimensions, StyleSheet } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { NeonScreen, neon } from '@/components/neon-screen';

const ICON_SIZE = 30;
const { width: SCREEN_WIDTH } = Dimensions.get('window');
type TabIconName = 'home' | 'practice' | 'ai' | 'social' | 'profile';

function TabIcon({ name, color }: { name: TabIconName; color: string }) {
  if (name === 'home') {
    return (
      <Svg width={ICON_SIZE} height={ICON_SIZE} viewBox="0 0 24 24" fill={color}>
        <Path d="M12 3l9 8h-3v9h-4v-6h-4v6H6v-9H3z" />
      </Svg>
    );
  }

  if (name === 'practice') {
    return (
      <Svg width={ICON_SIZE} height={ICON_SIZE} viewBox="0 0 24 24" fill={color}>
        <Path d="M12 3a3 3 0 00-3 3 3 3 0 00-3 3 3 3 0 000 6 3 3 0 003 3 3 3 0 006 0 3 3 0 003-3 3 3 0 000-6 3 3 0 00-3-3 3 3 0 00-3-3z" />
      </Svg>
    );
  }

  if (name === 'ai') {
    return (
      <Svg width={ICON_SIZE} height={ICON_SIZE} viewBox="0 0 24 24" fill={color}>
        <Rect x="5" y="7" width="14" height="11" rx="3" />
        <Circle cx="9.5" cy="12" r="1.4" fill="#101822" />
        <Circle cx="14.5" cy="12" r="1.4" fill="#101822" />
        <Rect x="11" y="3" width="2" height="3" />
      </Svg>
    );
  }

  if (name === 'social') {
    return (
      <Svg width={ICON_SIZE} height={ICON_SIZE} viewBox="0 0 24 24" fill={color}>
        <Path d="M6 4h12v3a4 4 0 01-4 4h-4A4 4 0 016 7zM4 5h2v2a2 2 0 01-2-2zm14 0h2a2 2 0 01-2 2zM10 12h4v4h3v3H7v-3h3z" />
      </Svg>
    );
  }

  return (
    <Svg width={ICON_SIZE} height={ICON_SIZE} viewBox="0 0 24 24" fill={color}>
      <Circle cx="12" cy="8" r="4" />
      <Path d="M4 20a8 8 0 0116 0z" />
    </Svg>
  );
}

export default function TabsLayout() {
  const insets = useSafeAreaInsets();
  const { t } = useTranslation();
  
  return (
    <NeonScreen>
      <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: 'transparent' }}>
        <View style={{ flex: 1 }}>
          <Tabs
            screenOptions={{
              headerShown: false,
              sceneStyle: StyleSheet.flatten({ backgroundColor: 'transparent' }),
              tabBarStyle: {
                backgroundColor: neon.surface,
                borderTopColor: neon.border,
                borderTopWidth: 1,
                height: 90 + insets.bottom,
                paddingBottom: insets.bottom > 0 ? insets.bottom : 14,
                paddingTop: 8,
                paddingHorizontal: 10,
                elevation: 0,
                justifyContent: 'space-around',
              },
              tabBarItemStyle: {
                flex: 1,
                minWidth: 70,
              },
              tabBarActiveTintColor: neon.primary,
              tabBarInactiveTintColor: neon.navInactive,
              tabBarLabelStyle: {
                fontSize: 12,
                fontWeight: '800',
                marginBottom: 4,
              },
              tabBarIconStyle: {
                marginBottom: 4,
              },
            }}
          >
            <Tabs.Screen
              name="index"
              options={{
                title: t('tabs.home'),
                tabBarIcon: ({ color }) => <TabIcon name="home" color={color} />,
              }}
            />
            <Tabs.Screen
              name="practice"
              options={{
                title: t('tabs.practice'),
                tabBarIcon: ({ color }) => <TabIcon name="practice" color={color} />,
              }}
            />
            <Tabs.Screen
              name="ai"
              options={{
                title: t('tabs.ai'),
                tabBarIcon: ({ color }) => <TabIcon name="ai" color={color} />,
              }}
            />
            <Tabs.Screen
              name="social"
              options={{
                title: t('tabs.social'),
                tabBarIcon: ({ color }) => <TabIcon name="social" color={color} />,
              }}
            />
            <Tabs.Screen
              name="profile"
              options={{
                title: t('tabs.profile'),
                tabBarIcon: ({ color }) => <TabIcon name="profile" color={color} />,
              }}
            />
            <Tabs.Screen name="tracks" options={{ tabBarButton: () => null }} />
            <Tabs.Screen name="courses" options={{ tabBarButton: () => null }} />
          </Tabs>
        </View>
      </SafeAreaView>
    </NeonScreen>
  );
}
