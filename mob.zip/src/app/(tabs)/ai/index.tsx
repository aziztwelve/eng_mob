import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Stack, Link, type Href } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { GradientTitle, neon, neonStyles } from '@/components/neon-screen';

const S = {
  surface: neonStyles.surface,
} as const;

const FEATURES = [
  {
    href: '/ai/chat',
    emoji: '💬',
    bg: 'rgba(46,236,200,0.14)',
    gradient: ['rgba(46,236,200,0.10)', 'rgba(46,236,200,0.02)'],
    title: 'Свободный чат',
    desc: 'Поговори с AI на изучаемом языке. История сохраняется.',
  },
  {
    href: '/ai/roleplay',
    emoji: '🎭',
    bg: 'rgba(255,77,141,0.14)',
    gradient: ['rgba(255,77,141,0.10)', 'rgba(255,77,141,0.02)'],
    title: 'Roleplay',
    desc: 'Ресторан, аэропорт, работа — выбери сценарий.',
  },
  {
    href: '/ai/writing',
    emoji: '📝',
    bg: 'rgba(40,220,233,0.14)',
    gradient: ['rgba(40,220,233,0.10)', 'rgba(40,220,233,0.02)'],
    title: 'Проверить эссе',
    desc: 'Оценка по 4 параметрам, исправленный текст и фидбэк.',
  },
  {
    href: '/ai/pronunciation',
    emoji: '🗣️',
    bg: 'rgba(168,85,255,0.15)',
    gradient: ['rgba(168,85,255,0.10)', 'rgba(168,85,255,0.02)'],
    title: 'Произношение',
    desc: 'Скажи фразу — AI оценит акцент и подскажет.',
  },
] as const;

export default function AIHubScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: 'transparent' }}>
      <Stack.Screen options={{ title: 'AI помощник' }} />
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 110 }}>
        {/* Header */}
        <View style={{ gap: 4, marginBottom: 20 }}>
          <GradientTitle width={260}>AI помощник</GradientTitle>
          <Text style={neonStyles.subtitle}>
            Практикуй язык в реалистичных сценариях
          </Text>
        </View>

        {/* Feature cards */}
        <View style={{ gap: 12 }}>
          {FEATURES.map((f) => (
            <Link key={f.href + f.title} href={f.href as Href} asChild>
              <Pressable style={{
                ...S.surface,
                borderRadius: 20, padding: 16,
                flexDirection: 'row', alignItems: 'center', gap: 14,
                overflow: 'hidden',
              }}>
                <LinearGradient
                  pointerEvents="none"
                  colors={f.gradient as [string, string]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ position: 'absolute', inset: 0 }}
                />
                {/* Icon */}
                <View style={{
                  width: 52, height: 52, borderRadius: 16,
                  backgroundColor: f.bg,
                  alignItems: 'center', justifyContent: 'center',
                }}>
                  <Text style={{ fontSize: 22 }}>{f.emoji}</Text>
                </View>
                <View style={{ flex: 1 }}>
                <Text style={{ color: neon.text, fontWeight: '900', fontSize: 17 }}>{f.title}</Text>
                  <Text style={{ color: neon.muted, fontWeight: '600', fontSize: 13, marginTop: 3 }}>
                    {f.desc}
                  </Text>
                </View>
                <Text style={{ color: neon.muted, fontSize: 22 }}>›</Text>
              </Pressable>
            </Link>
          ))}
        </View>

        {/* Совет дня */}
        <LinearGradient
          colors={[neon.tipBg, '#14204A']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            borderRadius: 20, padding: 16, overflow: 'hidden', marginTop: 8,
            borderWidth: 1, borderColor: neon.border,
            position: 'relative',
          }}
        >
          <View style={{
            display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 6,
            backgroundColor: 'rgba(0,0,0,0.3)',
            alignSelf: 'flex-start',
            borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5, marginBottom: 10,
          }}>
            <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>🤖 Совет дня</Text>
          </View>
          <Text style={{ color: neon.text, fontWeight: '900', fontSize: 18, marginBottom: 6 }}>
            «Попробуй Roleplay: кафе»
          </Text>
          <Text style={{ color: '#D7E2F0', fontWeight: '600', fontSize: 13, maxWidth: '70%' }}>
            5 реплик — и закрепишь 8 новых слов.
          </Text>
          <Text style={{ position: 'absolute', right: 8, bottom: -6, fontSize: 74 }}>🦉</Text>
        </LinearGradient>
      </ScrollView>
    </View>
  );
}
